// Server side C/C++ program to demonstrate Socket programming
#include <unistd.h>
#include <stdio.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>
#define PORT 8080
#define ADD 1
#define ABS 2
#define MUL 3
#define NOT 4
#define OTHER 5

int get_next_space(char* str, int start){
    int i;
    for(i = start; str[i] != ' ' && i < strlen(str); i++);
    return i == strlen(str) ? -1 : i;
}

int get_int(char* str, int start){
    int i, res = 0;
    for(i = start; i < strlen(str) && str[i] >= '0' && str[i] <= '9'; i++){
        res *= 10;
        res += (str[i] - '0');
    }
    return res;
}

int main(int argc, char const *argv[])
{
	int server_fd, new_socket, valread;
	struct sockaddr_in address;
	int opt = 1;
	int addrlen = sizeof(address);
	char buffer[1024] = {0};
	char *hello = "Hello\n";
    char *del;

	// Creating socket file descriptor
	if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0)
	{
		perror("socket failed");
		exit(EXIT_FAILURE);
	}

	// Forcefully attaching socket to the port 8080
	if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT,
												&opt, sizeof(opt)))
	{
		perror("setsockopt");
		exit(EXIT_FAILURE);
	}
	address.sin_family = AF_INET;
	address.sin_addr.s_addr = INADDR_ANY;
	address.sin_port = htons( PORT );

	// Forcefully attaching socket to the port 8080
	if (bind(server_fd, (struct sockaddr *)&address,
								sizeof(address))<0)
	{
		perror("bind failed");
		exit(EXIT_FAILURE);
	}
	if (listen(server_fd, 3) < 0)
	{
		perror("listen");
		exit(EXIT_FAILURE);
	}
	if ((new_socket = accept(server_fd, (struct sockaddr *)&address,
					(socklen_t*)&addrlen))<0)
	{
		perror("accept");
		exit(EXIT_FAILURE);
	}

    while(1){
	valread=read(new_socket, buffer,1024); // Read the string
	int space1; // The first space
	int space2; // The second space
	int a, b, c; // Three integers for calculating.
	char kill[5]="kill"; // The kill string.
	char answer[1024]; // The ansewr string.
	if(!strncmp(buffer, "add", 3)){ // Judge the string.
		opt = ADD;
	}else if(!strncmp(buffer, "abs", 3)){
		opt = ABS;
	}else if(!strncmp(buffer, "mul", 3)){
		opt = MUL;
	}else if(!strncmp(buffer, "kill", 4)){
		opt = NOT;
	}else {
		opt = OTHER;
	}
	
	switch(opt){
		case ADD: // Add two integers and return to client.
			space1 = get_next_space(buffer, 0);
			space2 = get_next_space(buffer, space1+1);
			a = get_int(buffer, space1+1);
			b = get_int(buffer, space2+1);
			c = a + b;
			sprintf(answer, "%d", c);
			send(new_socket, answer, sizeof(answer), 0);
			break;
		case ABS: // Absolute the integer and return to client.
			space1 = get_next_space(buffer, 0);
			if(buffer[space1+1] == '-')
				space1++;
			a = get_int(buffer, space1+1);
			sprintf(answer, "%d", a);
			send(new_socket, answer, sizeof(answer), 0);
			break;
		case MUL: // Multiple two integers and return to client.
			space1 = get_next_space(buffer, 0);
			space2 = get_next_space(buffer, space1+1);
			a = get_int(buffer, space1+1);
			b = get_int(buffer, space2+1);
			c = a * b;
			sprintf(answer, "%d", c);
			send(new_socket, answer, sizeof(answer), 0);
			break;
		case NOT: // Return kill to client.
			send(new_socket, kill, sizeof(kill), 0);
			break;
		case OTHER: // Return Hello to client.
			send(new_socket, hello, sizeof(hello), 0);
			break;
	}
	if(opt == NOT) // If the string is equal to kill, the loop will stop.
		break;
    }

	return 0;
}
