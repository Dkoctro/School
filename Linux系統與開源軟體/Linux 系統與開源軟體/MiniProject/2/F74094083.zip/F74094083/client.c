// Client side C/C++ program to demonstrate Socket programming
#include <stdio.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
#define PORT 8080

int main(int argc, char const *argv[])
{
	int sock = 0, valread;
	struct sockaddr_in serv_addr;
	char *hello = "Hello from client";
	char buffer[1024] = {0};

    usleep(500000);

	if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		printf("\n Socket creation error \n");
		return -1;
	}

	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(PORT);

	// Convert IPv4 and IPv6 addresses from text to binary form
	if(inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr)<=0)
	{
		printf("\nInvalid address/ Address not supported \n");
		return -1;
	}

	if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0)
	{
		printf("\nConnection Failed \n");
		return -1;
	}
	int count = 0; // Avoid the last newline
	while(1){
		for(int i = 0; i < sizeof(buffer); i++) // Initialize the buffer.
			buffer[i] = '\0';
		if(gets(buffer) != '\n'){ // Get the string
			send(sock, buffer, strlen(buffer), 0); // Send the string
		}
		valread = read(sock, buffer, 1024); // Read the return string
		if(!strncmp(buffer, "kill", 4)){ // If the return string is kill, stop the program
			close(sock);
			break;
		} else {
			if(count != 0) // When the count isn't zero, it will print newline first, then print the string after it.
				printf("\n");
			printf("%s", buffer); // Output the string on file
		}
		count = 1;
   	}
   

	return 0;
}
