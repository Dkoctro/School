#!/bin/bash

touch missing_list
touch wrong_list

mkdir -p ./compressed_files/{rar,tar.gz,unknown,zip}

while read id
do
	file_Correct=$(find /home/vb/Downloads/Linux_Week5_Lab/compressed_files -type f -name "${id}.zip" -o -type f -name "${id}.rar" -o -type f -name "${id}.tar.gz" -o -type f -name "${id}.dika")
	file_Dika=$(find /home/vb/Downloads/Linux_Week5_Lab/compressed_files -type f -name "${id}.dika")
	file_Zip=$(find /home/vb/Downloads/Linux_Week5_Lab/compressed_files -type f -name "${id}.zip")
	file_Rar=$(find /home/vb/Downloads/Linux_Week5_Lab/compressed_files -type f -name "${id}.rar")
	file_Tar=$(find /home/vb/Downloads/Linux_Week5_Lab/compressed_files -type f -name "${id}.tar.gz")
	
	if [ -z "${file_Correct}" ]; then
		echo ${id} >> missing_list		
	elif [ ! -z "${file_Dika}" ]; then
		echo ${id} >> wrong_list
		mv "${file_Dika}" /home/vb/Downloads/Linux_Week5_Lab/compressed_files/unknown
	elif [ ! -z "${file_Rar}" ]; then
		unrar x ${file_Rar} /home/vb/Downloads/Linux_Week5_Lab/compressed_files/rar
		mv "${file_Rar}" /home/vb/Downloads/Linux_Week5_Lab/compressed_files/rar		
	elif [ ! -z "${file_Tar}" ]; then
		tar xf ${file_Tar} -C /home/vb/Downloads/Linux_Week5_Lab/compressed_files/tar.gz
		mv "${file_Tar}" /home/vb/Downloads/Linux_Week5_Lab/compressed_files/tar.gz		
	elif [ ! -z "${file_Zip}" ]; then
		unzip ${file_Zip} -d /home/vb/Downloads/Linux_Week5_Lab/compressed_files/zip
		mv "${file_Zip}" /home/vb/Downloads/Linux_Week5_Lab/compressed_files/zip
	fi
done < student_id
